@echo off
start cmd /k python script.py