import time
import os
import sys

def print_welcome_message():
    color_code = "\033[38;2;0;255;223m"
    reset_code = "\033[0m"
    print(f"{color_code}\033[1mBienvenue PB.{reset_code}")

def choose_file():
    while True:
        print("\nSélectionnez un fichier :")
        print("1. Conversation interuniverselle (clemz.essentia)")
        print("2. Recherche d'univers (□.essentia)")
        choice = input("Tapez 1 ou 2 pour choisir le fichier : ")
        if choice == "1":
            return "clemz.essentia"
        elif choice == "2":
            return "□.essentia"
        else:
            print("Choix invalide. Essayez à nouveau.")

def choose_mode():
    while True:
        print("\nChoisissez le mode de lecture :")
        print("1. Mode manuel (appuyer sur entrée pur afficher chaque ligne)")
        print("2. Mode automatique (afficher le fichier en entier automatiquement)")
        mode = input("Tapez 1 ou 2 pour choisir le mode : ")
        if mode in ["1", "2"]:
            return mode
        else:
            print("Choix invalide. Essayez à nouveau.")

print_welcome_message()

file_name = choose_file()
mode = choose_mode()

script_dir = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(script_dir, file_name)

if __name__ == "__main__":
    if not sys.stdout.isatty():
        if sys.platform.startswith("win"):
            os.system(f'start cmd /k python "{__file__}"')
        elif sys.platform.startswith("linux") or sys.platform.startswith("darwin"):
            os.system(f'x-terminal-emulator -e python3 "{__file__}" &')
        else:
            print("Système non supporté.")
            sys.exit(1)
        sys.exit(0)

try:
    with open(file_path, "r", encoding="utf-8") as file:
        lines = file.readlines()

    if mode == "1":
        i = 0
        while i < len(lines):
            current_line = lines[i].rstrip("\n")
            
            if current_line.strip() != "":
                print(current_line, flush=True)
                input()  
                i += 1
            else:
                print(current_line, flush=True)
                if i + 1 < len(lines):
                    next_line = lines[i+1].rstrip("\n")
                    print(next_line, flush=True)
                    i += 2
                else:
                    i += 1
                input()  

    elif mode == "2":
        for line in lines:
            print(line.rstrip("\n"), flush=True)
            time.sleep(0.001)

except FileNotFoundError:
    print("Fichier introuvable.")
except Exception as e:
    print(f"Erreur : {e}")
